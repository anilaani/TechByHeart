from django.shortcuts import render
from django.views import View
from django.contrib.auth import authenticate as auth, login as auth_login
from django.contrib.auth.models import User
from django.contrib import messages
from .forms import LoginForm,ProductForm
from django.http import HttpResponseRedirect
# Create your views here.
class HomePage(View):
    def get(self,request):
        return render(request,"home.html")
class Login(View):
    def post(self,request):
        print("................")
        email = request.POST.get("email")
        password = request.POST.get("password")
        user =  auth(request,email=email, password=password)
        if user is not  None:
            auth_login(request, user,backend='django.auth.backends.ModelBackend')
            user = User.Objects.get(email=request.user)
            return render(request,'products.html')
        else:
            messages.warning(request,"invalid....")
            form = LoginForm()
            return render(request,'login.html')

class CreateProduct(View):
    def get(self,request):
        productform = ProductForm()
        return render(request,"product.html",{'productform':productform})
    def post(self, request):
        name = request.POST.get("name")
        subcategory = request.POST.get("subcategory")
        category = request.POST.get("category")
        unitprice = request.POST.get("unitprice")
        stock = request.POST.get("stock")
        productform = ProductForm(request.POST)
        if productform.is_valid():
            form = productform.save()
            form.save()
            return render(request,'listview.html',{'productform':productform})
        else:
            messages.warning(request,"invalid....")
            productform = ProductForm()
            return HttpResponseRedirect('Home')
