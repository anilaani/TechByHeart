from django import forms
from django.contrib.auth.models import User
from .models import Product
class LoginForm(forms.ModelForm):
    email = forms.CharField(widget=forms.EmailField)
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        Model = User
        fields = ('email','password')

class ProductForm(forms.ModelForm):
    name = forms.CharField(widget=forms.TextInput)
    subcategory = forms.CharField(widget=forms.TextInput)
    category = forms.CharField(widget=forms.TextInput)
    unitprice = forms.CharField(widget=forms.TextInput)
    stock = forms.CharField(widget=forms.TextInput)

    class Meta:
        Model = Product
        fields = ('name','subcategory','category','unitprice','stock')