from django.urls import path,include
from .import views

urlpatterns = [
    path('', views.HomePage.as_view(),name='Home'),
    path('Login/', views.Login.as_view(),name='Login'),
    path('CreateProduct/', views.CreateProduct.as_view(),name='CreateProduct'),
]
